/************************************
 Program to convert binary to decimal
 ************************************/
#include <stdio.h>
#include <math.h> // Include the math library for pow function

int main()
{ 
    int n, sum = 0, original, m;
    printf("Enter the number: ");
    scanf("%d", &n); 

    while (n > 0)
    {
        int p;
        m = n % 10;
        sum = sum + (m * pow(2, p)); 
        n = n / 10; 
        p++; 
    }
    
    printf("The decimal number is : %d\n", sum); 
    return 0; 
}

