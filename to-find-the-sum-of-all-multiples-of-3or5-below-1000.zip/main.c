/***************************************************
 To find the sum of all multiples of 3or5 below 1000
 *****************************************************/
#include<stdio.h>
void main()
{
    int i,m,n,sum=0;
    for(i=0;i<1000;i++)
    {
    if(i%3==0||i%5==0)
    {
        sum=sum+i;
    }
    }
    printf("%d",sum);
}
