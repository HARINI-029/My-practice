
//PRINTING DAYS OF THE WEEK//
#include <stdio.h>

void main()
{
   printf("The Days Of Week\n");
   printf(" MONDAY\n");
   printf(" TUESDAY\n");
   printf(" WEDNESDAY\n");
   printf(" THRUSDAY\n");
   printf(" FRIDAY\n");
   printf(" SATURDAY\n");
   printf(" SUNDAY\n");
   printf(" TOTAL 7 DAYS");
}
