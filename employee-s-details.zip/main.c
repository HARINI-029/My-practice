
#include <stdio.h>

void main()
{ 
    printf("two employees  details\n");
    printf("employee 1 : HARINI\n");
    printf("employee 2: HARSHINI\n");
   int id1;
   printf("enter the first employee's id\n");
   scanf("%d",&id1);
   int id2;
   printf("enter the second  employee's id\n");
   scanf("%d",&id2);
   long int ph1;
   printf("enter the first employee's phone number\n");
   scanf("%ld",&ph1);
   long int ph2;
   printf("enter the second employee's phone number\n");
   scanf("%ld",&ph2);
   long int adhar1;
   printf("enter the first employee's adhar number\n");
   scanf("%ld",&adhar1);
    long int adhar2;
   printf("enter the second employee's adhar number\n");
   scanf("%ld",&adhar2);
   int height1;
   printf("enter the height of first employee\n");
   scanf("%d",&height1);
   int height2;
   printf("enter the height of second employee\n");
   scanf("%d",&height2);
    int weight1;
   printf("enter the weight of first employee\n");
   scanf("%d",&weight1);
   int weight2;
   printf("enter the weight of second employee\n");
   scanf("%d",&weight2);
   printf("THANK YOU FOR YOUR PATIENCE ! HAVE A NICE DAY\n");
}
   
   

   
