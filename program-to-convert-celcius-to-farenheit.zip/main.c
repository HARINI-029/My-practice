
#include <stdio.h>

void main()
{
  float c=25;
  int f;
  f=(9*c/5)+32;
  printf("the farenheit temperature is:%d\n",f);
}
