//Explicit Conversion[int to double]
#include <stdio.h>

void main()
{
   double x= 1.2;
   int sum =(int)x+1;
   printf("sum=%d", sum);
}
