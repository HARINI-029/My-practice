class Main 
{
    public static void main(String args[]) 
    {
        int num;
        num=100;
        num=num*2;
        System.out.println("the answer is "+num);
    }
}