//sum of multiples of table 2
#include <stdio.h>
#include <math.h>

void main() {
    int x = 2, m;
    int sum = 0; 
    for (int i = 1; i < 11; i++) {
        m = x * i;
        sum = sum + m;
    }
    printf("%d", sum);
}
