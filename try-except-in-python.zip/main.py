'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
try:
    print(x)
except:
    print("error")
    
try:
    x=20
    ##print(x)
except:
    print("wrong")
else:
    print(x) 
finally:
    print("bello") 
    
try:
    x=20
x<0:
    raise exception ("hi")
    
