
//PROGRAM FOR IMPLICIT CONVERSION[CHAR TO INT]
#include <stdio.h>

void main()
{
   int x = 10;
   char y ='a';
   x=x+y;
   float z=x+1;
   printf("x=%d\n",x);
   printf("y=%f\n",z);
}
